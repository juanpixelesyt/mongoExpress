const express=require('express')
const router=express.Router();
const item=require('../models/Producto')

//Registrar un producto

//Consultar todos los productos

//Consultar productos por id

//Modificar datos del producto

//leiminar un producto

module.exports=router;
